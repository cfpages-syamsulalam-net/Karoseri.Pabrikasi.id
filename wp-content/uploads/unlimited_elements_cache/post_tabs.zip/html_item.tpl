<li class="ue_post_tabs-item">
  <a class="ue_post_tabs-item-anchor" href="#btss-{{item.item_index}}{{uc_id}}">
    {% if show_increment == "true" %}<div class="ue_post_tabs_increment">{{item.item_index}}</div>{% endif %}
    {% if tab_title_source == "post_title" %}{{item.post.title|raw}}{% endif %}
    {% if tab_title_source == "post_intro" %}{{item.post.intro}}{% endif %}
    {% if tab_title_source == "post_date" %}{{item.post.date|ucdate("d F Y, H:i")|raw}}{% endif %}
    {% if tab_title_source == "custom_text" %}{{custom_text}}{% endif %}
    {% if tab_title_source == "custom_field" %}
      {% set custom_field_value = ucfunc("get_post_custom_field", item.post_list.id,custom_meta_field_data)%} 
      {{custom_field_value|raw}}
    {% endif %}
  </a>
</li>