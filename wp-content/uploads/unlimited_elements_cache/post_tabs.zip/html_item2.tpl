<div id="btss-{{item.item_index}}{{uc_id}}" class="tab-container panes" >
  <div class="ue_post_tabs_container">
    {% if show_post_image == "true" %}
       <div class="ue_post_image">
         {% if item.post.image is empty %}
           {% if fallback_image is empty %}
           <img src="{{uc_assets_url}}/missing-image.png" alt="No Image">
           {% else %}
           <img src="{{fallback_image}}" alt="No Image">
           {% endif %}
         {% else %}
         <img src="{{item.post.image}}" {{item.post.image_attributes|raw}}>
         {% endif %}
       </div>
    {% endif %}
    <div class="ue_post_tab_content">
      {% if show_post_title == "true" %}<div class="ue_post_title">{{item.post.title|raw}}</div>{% endif %}
      {% if show_post_date == "true" %}<div class="ue_post_date">{{item.post.date|ucdate("d F Y")|raw}}</div>{% endif %}
      
      
      
      		  
      	  <div class="ue-meta-data">
            {% if show_time_ago == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{time_ago_icon_html|raw}}</span> {{text_before_time_ago|raw}} {{item.post.date|ucdate("time_ago")|raw}}</div>{% endif %}
            {% if show_author == "true" %}
            <div class="ue-grid-item-meta-data">
                   {% if author_element == "icon" %}<span class="ue-grid-item-meta-data-icon">{{author_icon_html|raw}}</span>{% endif %}
                   {% if author_element == "avatar" %}<span class="ue-grid-item-meta-data-avatar">{% set author2 = getPostAuthor(item.post.author_id,true,true) %}<img src="{{author2.avatar_url|raw}}"></span>{% endif %}
                   {{text_before_author|raw}} {% set author = getPostAuthor(item.post.author_id) %} <a href="{{author.url_posts}}">{{author.name}} </a>
            </div>
            {% endif %}
            
        
			{% if show_comments == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{comments_icon_html|raw}}</span> {{text_before_comments|raw}}  {% set num_comments = ucfunc("get_num_comments", item.post_list.id) %} {{num_comments}} </div>{% endif %}

            {% if show_custom_meta_one == "true" %}
            	{% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_one)%} 
          		
            	{%if(meta_field_one_convert == "date")%}
          			{% set custom_field_value = custom_field_value|ucdate(meta_one_date_dest,meta_one_date_source) %}
          		{% endif %}
				
				{% if(custom_field_value is not empty or custom_meta_icon_hide == "false") %}
					<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_one_html|raw}}</span> {{custom_meta_text_before_one|raw}} {{custom_field_value|raw}}</div>
            	{% endif %}
				
            {% endif %}
            
            {% if show_custom_meta_two == "true" %}
            	{% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_two)%} 
          		
            	{%if(meta_field_two_convert == "date")%}
          			{% set custom_field_value = custom_field_value|ucdate(meta_two_date_dest,meta_two_date_source) %}
          		{% endif %}
				
            	{% if(custom_field_value is not empty or custom_meta_icon_hide == "false") %}
            		<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_two_html|raw}}</span> {{custom_meta_text_before_two|raw}} {{custom_field_value|raw}}</div>
            	{% endif %}
            	
            {% endif %}
            
            {% if show_custom_meta_three == "true" %}
            	{% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_three)%} 
            
            	{% if(custom_field_value is not empty or custom_meta_icon_hide == "false") %}
            	<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_three_html|raw}}</span> {{custom_meta_text_before_three|raw}} {{custom_field_value|raw}}</div>
            	{% endif %}
            
            {% endif %}
            
            {% if show_custom_meta_four == "true" %}
            	{% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_four)%} 
            
            	{% if(custom_field_value is not empty or custom_meta_icon_hide == "false") %}
            	<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_four_html|raw}}</span> {{custom_meta_text_before_four|raw}} {{custom_field_value|raw}}</div>
            	{% endif %}
            
            {% endif %}
            
            {% if show_custom_meta_five == "true" %}
            	{% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_five)%} 
            	
            	{% if(custom_field_value is not empty or custom_meta_icon_hide == "false") %}
            	<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_five_html|raw}}</span> {{custom_meta_text_before_five|raw}} {{custom_field_value|raw}}</div>
            	{% endif %}
            
            {% endif %}
			
            {% if debug_meta_fields == "true" %}
              <div class="ue-debug-meta">
                {{ucfunc("put_post_meta_debug",item.post.id)}}
              </div>
            {% endif %}  
            
          </div>
      
      {% if show_post_text == "true" %}<{{text_tag_wrapper}} class="ue_post_intro">{{item.post.intro_full|truncate(intro_number_of_characters)|raw}}</{{text_tag_wrapper}}>{% endif %}
      {% if show_post_full_content == "true" %}<{{text_tag_wrapper}} class="ue_post_intro">{{ucfunc("put_post_content", item.post.id, item.post.content)}}</{{text_tag_wrapper}}>{% endif %}
      {% if show_post_button == "true" %}<div><a class="ue_post_link {{item.post.dynamic_popup_link_class}}" href="{{item.post.link}}" target="{{open_links_in_new_tab}}" {{item.post.dynamic_popup_link_attributes|raw}} >{{button_text|raw}}</a></div>{% endif %}
    </div>
  </div> 
</div>