<div class="uc_bold_tabs ue_post_tabs {{remote_parent.class|raw}} {{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" data-scrolltohead="{{scroll_to_head}}" data-close-active="{{close_active_tab_on_click}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
    	<ul class="tabs uc-items-wrapper ue-tab-btns">
        	{{put_items()}}
        </ul>
        <div class="panel-container uc-items-wrapper2">
			{{put_items2()}}
        </div>

    <div class="uc-accordion-contents-template" style="display:none">
      <div class="uc-accordion-icon">
        <span class="uc-accordion-icon-expand">{{accordion_expand_icon_html|raw}}</span>
        <span class="uc-accordion-icon-collapse">{{accordion_collapse_icon_html|raw}}</span>
      </div>
    </div>

</div>