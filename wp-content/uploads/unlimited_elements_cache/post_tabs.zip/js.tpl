{{ ucfunc("put_docready_start") }}
		
  var jQuerytabs = jQuery('#{{uc_id}}');
  var htmlAccordion = jQuerytabs.find(".uc-accordion-contents-template").html();

  var options = {
    startCollapsed: '{{start_hidden}}',
   {% if accordion_breakpoint == "true" %}
    breakpoint: {{responsive_breakpoint}},
    collapsible: 'accordion', 
   {% else %}
    collapsible: false,
   {% endif %}
    accordionAnchorHTML:htmlAccordion ,
    breakpoint: {{responsive_breakpoint}},
    setHash: {{set_url_hash}},
    
  };

  jQuerytabs.responsivePostTabs('init', options); 

  {% if uc_inside_editor == "yes" %}
    var objTab = jQuerytabs.find('.r-tabs-anchor');
   
    //Block anchor jumping in Elementor Editor
    objTab.on('click', function(e) {
        if (window.parent && window.parent.elementor) {
            // Stop the browser from scrolling to the ID
            e.preventDefault(); 

            // Stop the event from bubbling up to Elementor's UI handlers
            e.stopPropagation(); 

            // Manually trigger the tab switch if the plugin doesn't catch it
            // (Optional: only if the tabs stop working entirely in the editor)
        }
    });
  {% endif %}    
  
  {% if scroll_to_head != "off" %}
  
    var objTab = jQuerytabs.find('.r-tabs-anchor');
    var isDesktopViewport = window.matchMedia("(min-width: 1024px)");
    var isMobileViewport = window.matchMedia("(max-width: 1024px)");

    function scrollToTop(offsetTop){
		console.log("scrolled to top")
      jQuery('html, body').animate({
        scrollTop: offsetTop + {{scroll_to_head_offset}}
      }, 400);
    }

    objTab.click(function(){
      	var jQuerytabsOffsetTop = jQuerytabs.offset().top;
		var tabsItemOffsetTop = jQuery(this).offset().top;

        if(isDesktopViewport.matches == true && jQuerytabs.data("scrolltohead") == "desktop")
            scrollToTop(jQuerytabsOffsetTop);

        if(isMobileViewport.matches == true && jQuerytabs.data("scrolltohead") == "mobile")
           	scrollToTop(tabsItemOffsetTop);

        {% if (scroll_to_head == "desktop+mobile") %}
        
        	if(isMobileViewport.matches == true)
            	scrollToTop(tabsItemOffsetTop);

            if(isDesktopViewport.matches == true)
            	scrollToTop(jQuerytabsOffsetTop);

        {% endif %}

    });

    {% endif %}
    
   jQuerytabs.on("uc_ajax_refreshed",function(){
       //remove active class
       jQuerytabs.responsivePostTabs("init", "destroy");
     
        setTimeout(function(){
          jQuerytabs.responsivePostTabs("reinit", options, jQuerytabs[0]);  
        },300);
   });
     
  	var objRemoteOptions = {
    	class_items:"ue_post_tabs-item",
    	class_active:"r-tabs-state-active",
    	selector_item_trigger:".ue_post_tabs-item-anchor"
    };
    
  	{{ucfunc("put_remote_parent_js","jQuerytabs","objRemoteOptions")}}     
    	
{{ ucfunc("put_docready_end") }}